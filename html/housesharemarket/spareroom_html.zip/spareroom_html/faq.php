

<?php include("header.php");  ?>
<!-- Breadcrumb Bar -->
<div class="section breadcrumb-bar solid-blue-bg">
   <div class="inner">
      <div class="container">
         <p class="breadcrumb-menu">
            <a href="index.php"><i class="ion-ios-home"></i></a>
            <i class="ion-ios-arrow-right arrow-right"></i>
            <a href="#0">Faq's</a>
            <i class="ion-ios-arrow-right arrow-right"></i>
            <a href="#0">Faq's</a>
         </p>
         <!-- end .breabdcrumb-menu -->
         <h2 class="breadcrumb-title">Frequently asked questions</h2>
      </div>
      <!-- end .container -->
   </div>
   <!-- end .inner -->
</div>
<!-- end .section -->
<!-- Blog priacy policy -->
<div class="section blog-standard-section">
   <div class="inner">
      <div class="inner">
         <div class="container">
            <h3 class="text-center">Frequently asked questions</h3>
            <p class="text-center">Your content goes here.</p>
            <BR>
            <div id="faq" class="tab-pane fade in active">
               <div class="faqs-list-wrapper">
                  <div class="panel-group-wrapper">
                     <div class="panel-group faqs-group for-employers" id="accordion2" role="tablist" aria-multiselectable="true">
                        <div class="panel panel-default">
                           <div class="panel-heading" role="tab" id="headingfour">
                              <h4 class="panel-title">
                                 <a class="collapsed flex space-between" role="button" data-toggle="collapse" data-parent="#accordion2" href="#collapsefour" aria-expanded="false" aria-controls="collapsefour">
                                 Do you have any free pricing plan?<span class="icon"><i class="ion-ios-plus-empty"></i></span>
                                 </a>
                              </h4>
                           </div>
                           <!-- end .panel-heading -->
                           <div id="collapsefour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingfour" aria-expanded="false" style="height: 0px;">
                              <div class="panel-body">
                                 <p>Admiration we surrounded possession frequently he. Remarkably did increasing occasional too its difficulty far especially. Known tiled but sorry joy balls. Bed sudden manner indeed fat now feebly. Face do with in need of wife paid that be.</p>
                              </div>
                              <!-- end .panel-body -->
                           </div>
                           <!-- end .panel-collapse -->
                        </div>
                        <!-- end .panel -->
                        <div class="panel panel-default">
                           <div class="panel-heading" role="tab" id="headingfive">
                              <h4 class="panel-title">
                                 <a class="collapsed flex space-between" role="button" data-toggle="collapse" data-parent="#accordion2" href="#collapsefive" aria-expanded="true" aria-controls="collapsefive">
                                 How many job I can post?<span class="icon"><i class="ion-ios-plus-empty"></i></span>
                                 </a>
                              </h4>
                           </div>
                           <!-- end .panel-heading -->
                           <div id="collapsefive" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingfive" aria-expanded="true" style="height: 0px;">
                              <div class="panel-body">
                                 <p>Nullam semper erat arcu, ac tincidunt sem venenatis vel. Curabitur at dolor ac ligula fermentum euismod ac ullamcorper nulla. Integer blandit ultricies aliquam. Pellentesque quis dui varius, dapibus velit id, iaculis ipsum. Morbi ac eros feugiat, lacinia elit ut, elementum turpis. Curabitur justo sapien, tempus sit amet rutrum eu, commodo eu lacus. Morbi in ligula nibh. Maecenas ut mi at odio hendrerit eleifend tempor vitae augue.</p>
                              </div>
                              <!-- end .panel-body -->
                           </div>
                           <!-- end .panel-collapse -->
                        </div>
                        <!-- end .panel -->
                        <div class="panel panel-default">
                           <div class="panel-heading" role="tab" id="headingsix">
                              <h4 class="panel-title">
                                 <a class="collapsed flex space-between" role="button" data-toggle="collapse" data-parent="#accordion2" href="#collapsesix" aria-expanded="false" aria-controls="collapsesix">
                                 Is there any dashboard that I can use to manage jobs/applications?<span class="icon"><i class="ion-ios-plus-empty"></i></span>
                                 </a>
                              </h4>
                           </div>
                           <!-- end .panel-heading -->
                           <div id="collapsesix" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingsix" aria-expanded="false" style="height: 0px;">
                              <div class="panel-body">
                                 <p>Admiration we surrounded possession frequently he. Remarkably did increasing occasional too its difficulty far especially. Known tiled but sorry joy balls. Bed sudden manner indeed fat now feebly. Face do with in need of wife paid that be.</p>
                              </div>
                              <!-- end .panel-body -->
                           </div>
                           <!-- end .panel-collapse -->
                        </div>
                        <!-- end .panel -->
                        <div class="panel panel-default">
                           <div class="panel-heading" role="tab" id="headingsix">
                              <h4 class="panel-title">
                                 <a class="collapsed flex space-between" role="button" data-toggle="collapse" data-parent="#accordion2" href="#collapsesix" aria-expanded="false" aria-controls="collapsesix">
                                 Is there any dashboard that I can use to manage jobs/applications?<span class="icon"><i class="ion-ios-plus-empty"></i></span>
                                 </a>
                              </h4>
                           </div>
                           <!-- end .panel-heading -->
                           <div id="collapsesix" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingsix" aria-expanded="false" style="height: 0px;">
                              <div class="panel-body">
                                 <p>Admiration we surrounded possession frequently he. Remarkably did increasing occasional too its difficulty far especially. Known tiled but sorry joy balls. Bed sudden manner indeed fat now feebly. Face do with in need of wife paid that be.</p>
                              </div>
                              <!-- end .panel-body -->
                           </div>
                           <!-- end .panel-collapse -->
                        </div>
                        <!-- end .panel -->
                        <div class="panel panel-default">
                           <div class="panel-heading" role="tab" id="headingsix">
                              <h4 class="panel-title">
                                 <a class="collapsed flex space-between" role="button" data-toggle="collapse" data-parent="#accordion2" href="#collapsesix" aria-expanded="false" aria-controls="collapsesix">
                                 Is there any dashboard that I can use to manage jobs/applications?<span class="icon"><i class="ion-ios-plus-empty"></i></span>
                                 </a>
                              </h4>
                           </div>
                           <!-- end .panel-heading -->
                           <div id="collapsesix" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingsix" aria-expanded="false" style="height: 0px;">
                              <div class="panel-body">
                                 <p>Admiration we surrounded possession frequently he. Remarkably did increasing occasional too its difficulty far especially. Known tiled but sorry joy balls. Bed sudden manner indeed fat now feebly. Face do with in need of wife paid that be.</p>
                              </div>
                              <!-- end .panel-body -->
                           </div>
                           <!-- end .panel-collapse -->
                        </div>
                        <!-- end .panel -->
                     </div>
                     <!-- end #accordion-tabs -->
                  </div>
                  <!-- end .panel-group-wrapper -->
               </div>
               <!-- end .faqs-list-wrapper -->
            </div>
            <!-- end #faq-tab-content -->
         </div>
         <!-- end .container -->
      </div>
      <!-- end .inner -->
   </div>
   <!-- end .inner -->
</div>
<!-- end .section -->
<?php include("footer.php");  ?>

